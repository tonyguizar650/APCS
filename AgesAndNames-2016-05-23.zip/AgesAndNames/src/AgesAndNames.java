/**
 * TONY G.
 * APCS/P19
 *10.26.15, REMASTERED on 12.2.15
 *I received no help
 *This program will ask for the names and ages of people and print them onto a file
 */
import java.util.*;
import java.io.*;
public class AgesAndNames {
	public static void main(String args[]) throws IOException {
		//creates new file
		FileWriter fw= new FileWriter("H:\\APCS\\javaWorkspace\\agesAndNames.txt");
		PrintWriter output= new PrintWriter(fw);
		
	    //create new scannner
	    Scanner scanner = new Scanner(System.in);
		//create a string array with a length of 5
		String[] names= new String[5];
		
		//go through each item in the array and add to it
		for(int i=0; i<names.length-1; i++){
		    System.out.print("Enter in a name: ");
		    names[i]= scanner.nextLine();
		}
		
		//create an array for ages
		int[] ages= new int[5];
		//ask for ages of names and store in int array
		for(int j=0; j<ages.length-1;j++){
		    System.out.print("How old is " + names[j] + "? : ");
		    ages[j]= scanner.nextInt();
		}
		//print out all names and ages
		for(int k=0;k<names.length-1;k++){
		 System.out.println(names[k] + " is " + ages[k] + " year(s) old.");   
		}
		//print all ages and names in a new file
		for(int k=0;k<names.length-1;k++){
			output.println(names[k] + " is " + ages[k] + " year(s) old.");
		}
		fw.close();
		output.close();
	}
}