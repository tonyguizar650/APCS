"""
Tony Guizar & Oscar Robles
This program will create an oval and a line with custom coordinates
"""

from graphics import *

"""
This method will draw an Oval. It looks an oval while we call the circle funtion because our code draws the circle with the
coordinates from the setCoords function on the axis, but python reads the pixels from the window and so the circle is streched and
looks like an oval.
"""
def draw_oval():
    #Creates window 300 pixels winde and 100 pixels tall
    win = GraphWin("Draw Oval",300,100)
    win.setCoords(-10,-10,10,10)
    #Draw x axis
    x_axis = Line(Point(-10,0),Point(10,0))
    x_axis.setArrow("both")
    x_axis.draw(win)
    #Draw Y Axis
    y_axis= Line(Point(0,-10),Point(0,10))
    y_axis.setArrow("both")
    y_axis.draw(win)
    #Draw the oval
    circle = Circle(Point(0,0),5)
    circle.draw(win)
    
    win.getMouse()
    win.close()

"""
This method will draw the following functions in the axis as a graph would draw the lines.
y = x in red    y = -x in blue       y = 3 in green      y = 2x - 4 in yellow
"""
def draw_lines():
    #Creates a new window different from the previous one with the same coordinates. 300 pixels tall and wide
    win = GraphWin("Draw Lines",300,300)
    win.setCoords(-10,-10,10,10)
    #Draw x axis
    x_axis = Line(Point(-10,0),Point(10,0))
    x_axis.setArrow("both")
    x_axis.draw(win)
    #Draw Y Axis
    y_axis= Line(Point(0,-10),Point(0,10))
    y_axis.setArrow("both")
    y_axis.draw(win)

    #Draw Red function y=x
    red_line=Line(Point(-10,-10),Point(10,10))
    red_line.setArrow("both")
    red_line.setFill("red")
    red_line.draw(win)

    #Draw Blue Function y=-x
    blue_line=Line(Point(-10,10),Point(10,-10))
    blue_line.setArrow("both")
    blue_line.setFill("blue")
    blue_line.draw(win)

    #Draw Green Function y=3
    green_line=Line(Point(-10,3),Point(10,3))
    green_line.setArrow("both")
    green_line.setFill("green")
    green_line.draw(win)

    #Draw Yellow function y=2x-4
    yellow_line=Line(Point(-3,-10),Point(7,10))
    yellow_line.setArrow("both")
    yellow_line.setFill("yellow")
    yellow_line.draw(win)


"""
This function will let the user choose whether they'd like
to run the draw_oval or the draw_lines code.
"""
def main():
    choice = raw_input("Enter O or L for [O]val or [L]ine")
    if choice == "O":
        draw_oval()
    else:
        draw_lines()

# run this code only if we're running this module
if __name__ == "__main__":
    main()   
