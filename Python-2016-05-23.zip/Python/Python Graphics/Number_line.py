
'''
Tony Guizar. This program will draw a number line
'''
from graphics import *

'''
This method will draw a horizontal line and draw arrows at the ends of it.It has a parameter win that tells the method in what window
to draw the horizontal line.
'''
def draw_number_line(win):
    #Draws the line with the two given endpoints
    line=Line(Point(100,150),Point(600,150))
    #This will draw an arrow on both sides of the line
    line.setArrow('both')
    line.draw(win)

'''
This method will create a vertical line that will be the tick mark that will be called
multiple times. It has a parameter win that tells the method in what window to draw the line and parameter x that is the x axis for
the tick mark, to be able to change it's position on the number line
'''
def draw_tick(win,x):
    tick=Line(Point(x,165),Point(x,135))
    tick.draw(win)
'''
This will draw the numbers under each tick mark on the numberline. It has a parameter win that tells the method in what window
to draw the numbers. The x parameter allows the numbers to be drawn anywhwere along the number line and the i parameter allows the
number to change each time for each tick mark.
'''
def draw_nums(win,x,i):
    text=Text(Point(x,125),i)
    text.draw(win)
    
'''
This method will draw the number line with the arrows, tick marks, and numbers a parameter win that tells the method in what window
to draw the number line, it has max and min arguments to be able to manipulate the length of the number line.
    '''
def call_number_line(win, minimum, maximum):
    #Draws the number line with domain [-10,10]
    draw_number_line(win)
    #Draws tick mark from min to max
    for i in range(21):
        draw_tick(win,140+21*i)
    #Draws numbers under tick marks 
    for i in range(minimum,maximum+1):
        draw_nums(win,350+21*i,i)
        
'''
This is the main method that calls the draw_number_line method and creates the
graphing window
'''
def draw():
    #Creates the window that is 800x300
    win=GraphWin('Number Line',800,300)
    win.yUp()
    call_number_line(win,-10,10)    
        
    return win
def main():
    win = draw()
    
    #closes window when user clicks on it
    win.getMouse()
    win.close()
if __name__=='__main__':
    main()
