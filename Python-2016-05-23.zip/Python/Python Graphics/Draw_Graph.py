'''
Tony Guizar. This Program will draw a bar graph showing the percentage distribution of
children in kindergarten by race and ethnicity.
'''
from graphics import *

'''
This method will create a vertical line that will be the tick mark that will be called multiple times. It has a parameter win that
tells the method in what window to draw the line and parameter x that is the x axis for the tick mark, to be able to change it's
position on the number line
'''
def draw_tick(win,x):
    tick=Line(Point(x,1),Point(x,-1))
    tick.draw(win)
'''
This will draw the numbers under each tick mark on the numberline. It has a parameter win that tells the method in what window
to draw the numbers. The x parameter allows the numbers to be drawn anywhwere along the number line and the i parameter allows the
number to change each time for each tick mark.
'''
def draw_nums(win,x,num):
    number=Text(Point(x,-2),num)
    number.draw(win)

'''
This method will draw the bar animation for the bar graph. X is the positionn on the x axis and y is the position on the y axis
'''
def draw_bars(win,x,y):
    #draws a horizontal blue bar to represent the distribution 
    bar=Rectangle(Point(0,y),Point(x,y+2))
    bar.setFill("blue")
    bar.draw(win)

'''
This method will display the text of the name of the race 
'''
def display_text(win,name,num):
    #draw the name of the race
    text_name=Text(Point(-5,num),name)
    text_name.draw(win)
'''
This method will display the numbers at the ends of the bar graphs
'''
def display_num(win,name,num,x):
    #draw the number next to the graph
    text_num=Text(Point(x,num),name)
    text_num.draw(win)
    
'''
This method will draw the axis for the graph
'''
def draw_axis(win):
    #Draw y and x axis using a horizontal and vertical line
    yaxis=Line(Point(0,0),Point(0,30))
    xaxis=Line(Point(0,0),Point(60,0))
    yaxis.setArrow("last")
    xaxis.setArrow("last")
    yaxis.draw(win)
    xaxis.draw(win)


'''
This main function will be responsable for creating the window and calling all the methods that draw the graphs
'''
def main():
    #This dictionary stores the race as the key and the distribution percentage as the value
    data={"White":51,"Black":14,"Hispanic":25,"Asian":5,"Native Am.":1.1,"Two or more":4}
    
    #Cretes graohing window 600X600
    win=GraphWin("Distribution of Kinder Students by Race/Ethnicity", 600,600)
    win.setCoords(-10,-10,60,50)
    
    #will draw a title in the graph
    title=Text(Point(20,45), "Percentage Distribution of Children in Kindergarten by Race/Ethnicity")
    title.draw(win)
    draw_axis(win)
    
    #This wil draw the tick marks to lavel the graph
    for i in range(0,60,10):
        draw_tick(win,i)
        draw_nums(win,i,i)
        
    #starting ostition on the y axis
    ypos=25
    #Draw the bar data for each race
    for race in data:
        draw_bars(win,data[race],ypos)
        display_text(win,race,ypos)
        display_num(win,data[race],ypos,data[race]+2)
        #decrement by 4 each time
        ypos-=4
    

    win.getMouse()
    win.close()

if __name__=="__main__":
    main()
