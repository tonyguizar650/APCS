'''
Tony Guizar.
This program will draw a face
'''
from graphics import *

'''
This method will draw an oval head for the face
'''
def draw_head(width,hight,win):
    head=Oval(Point(0,0),Point(width,hight))
    head.setFill('yellow')
    head.draw(win)
'''
This method will draw both of the eyes with the pupils
'''
def draw_eyes(width,hight,win):
    #Draw Circles for left eye and pupil
    left=Circle(Point(width/4,hight*.75), 80)
    left_pupil=Circle(Point(width/4,hight*.75), 40)
    left_pupil.setFill('black')
    left.setFill('white')
    left.draw(win)
    left_pupil.draw(win)

    #Draw cirles for right eye and pupil
    right=Circle(Point(width/2+width/4,hight*.75), 80)
    right_pupil=Circle(Point(width/2+width/4,hight*.75), 40)
    right_pupil.setFill('black')
    right.setFill('white')
    right.draw(win)
    right_pupil.draw(win)

'''
This method will draw the mouth
'''
def mouth(width,hight,win):
    #draw mouth as an oval
    mouth=Oval(Point(width/6,hight/2),Point(width/2+width/3,hight/4))
    mouth.setFill('white')
    mouth.draw(win)
'''
This method will draw a green triangle in the center of the face to be the nose
'''
def draw_nose(width,hight,win):
    
    nose = Polygon(Point(300,550),Point(250,450), Point(350,450))
    nose.setFill('green')
    nose.draw(win)
'''
Main function will execute all methods
'''
def main():
    #window measurements
    width=600
    hight=800
    #Draw window and invert x&y
    win = GraphWin("Face", width, hight)
    win.yUp()
    win.setBackground('green')

    #call methods to draw face
    draw_head(width, hight, win)
    draw_eyes(width, hight, win)
    mouth(width, hight, win)
    draw_nose(width, hight, win)


    win.getMouse()
    win.close()
    
'''
Will run this only if it is this program
'''
if __name__=="__main__":
    main()

