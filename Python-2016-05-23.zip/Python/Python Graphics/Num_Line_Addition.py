'''
Tony Guizar. This program will show addition on a number line. 
'''
from Number_line import draw
from graphics import *
import time
'''
This method will create the ball and return it at the end to be able to us it in my main mehod. It will take in 3 arguments. x is
the position on the x axis, color is the color of the circle and win tells the mehtod what window to draw the circles on
'''
def ball(x,color,win):
    circle=Circle(Point(x,160),10)
    circle.setFill(color)
    circle.draw(win)
    return circle
'''
This method will make the ball move and it will take in 3 arguments. amount is the amount the user wants to add or subtract. circle
tells the method that it wants to use the circle that was drawn in my first method. win tells the method where to draw 
'''
def move_ball(pos_neg,amount,circle,win):
    #wait for half a second
    time.sleep(.5)
    for i in range(amount*21):
        #move by 1 pixel amount*21 times
        time.sleep(.01)
        circle.move(pos_neg*1,0)
'''
This method will ask the user if they want to add or subtract and by how much and it will show on the number line
'''
def add_sub(circle,win):
    #ask user if he/she wants to add or subtract
    addsub=raw_input("Would you like to add or subtract? Enter 'a' for add or 's' for subrtact: ")
    # if they want to add it will move forward by however much they want
    if addsub == "a":
        num=int(raw_input("By how much ? Enter an integer: "))
        #if it is on number line
        if 0<=num and num<=10:
            move_ball(1,num,circle,win)
        else:
            print "input another number"
            add_sub(circle,win)
    #if they want to subtract it will move forward by however much they want
    elif addsub == "s":
        num=int(raw_input("By how much ? Enter an integer: "))
        #if it is on number line
        if 0<=num and num<=10:
            move_ball(-1,num,circle,win)
        else:
            print "input another number"
            add_sub(circle,win)
    else:
        print "Invalid"
        add_sub(circle,win)
   
'''
This method will ask the user if they would like to try again
'''
def again(win):
    #ask if they want to try again
    again=raw_input("Would you like to try again? input Y for yes or N for no: ")
    #redo ther program if they do
    if again.lower()=="y":
        win=draw()
        #TONY
        #TONY
        #TONY
        #TONY
        #FIX THE 390 SO THAT IT DOESN'T ALWAYS START AT THE CENTER. THIS IS BAD BECAUSE IF THE USER WANTS TO ADD OR SUBTRACT AGAIN, THEN THE USER WILL SEE THE CIRCLE START AT 0
        #HOWEVER, THE CODE WILL TECHNICALLY HAVE THE BALL AT SOME OTHER POINT (LIKE 9) EVEN THOUGH THE BALL LOOKS LIKE IT IS AT 0.
        ball(390,"red",win)
        circle=ball(390,"green",win)
        add_sub(circle,win)
        again(win)
    #close the window if they don't
    elif again.lower()=="n":
        win.close()
    #if they input anything else
    else:
        print "Invalid"
        again(win)
'''
main function calls everything
'''
def main():
    win=draw()
    ball(390,"red",win)
    circle=ball(390,"green",win)
    add_sub(circle,win)
    again(win)

    win.getMouse()
    win.close()

if __name__=="__main__":
    main()
