'''
TONY GUIZAR

In psychology, the STROOP TEST is a demonstration of interference in the reaction time of a task. When the name of a color (e.g., "blue", "green", or "red") is printed in a color
not denoted by the name (e.g., the word "red" printed in blue ink instead of red ink), naming the color of the word takes longer and is more prone to errors than when the color of the
ink matches the name of the color. The effect is named after John Ridley Stroop, who first published the effect in English in 1935. The effect has been used to create a psychological
test (Stroop test) that is widely used in clinical practice and investigation.
'''
from graphics import *
import random
import time

'''
This function will display the word of the color while being a different color
'''
def display_word(win,colors):

    #variable with the color of the word
    word_color=colors[random.randint(0,5)]
    
    #Display word of random color
    word=Text(Point(5,5.5), colors[random.randint(0,5)])
    #Color of word is random
    word.setFill(word_color)
    #Set sixe of the text
    word.setSize(35)
    word.draw(win)

    current_color=word_color
    
    ask_color(win,colors,current_color)
    word.undraw()
'''
This method will ask the user for the color of the word and keep track of the user's score
'''
#Have a variable that keeps track of the user's score
user_score=0
def ask_color(win,colors,current_color):
    # allows us to use the global variable user_score (global = accessible in any method)
    global user_score
    
    #ask the user the color of the word
    user_input=raw_input("What is the color of the word? : ")
    if user_input.lower() == current_color:
        print "correct"
        #add a point to the user's score
        user_score+=1
    else:
        print "Incorrect"
       


'''
This method will start the game once the user preses enter
'''
def start_game(win,colors,score_text):
    global user_score
    #SART GAME when user hits enter
    start_text=Text(Point(5,5),"PRESS ENTER WHEN YOU WANT TO START")
    start_text.setSize(15)
    start_text.draw(win)
    print "Enter the color you see NOT THE ACTUAL WORD"
    print "You get 10 tries. There are 10 possible points."
    print "You will be timed. Time Starts when you hit enter."
    
    raw_input("")
    
    
    start_text.undraw()
    #Start Time
    start_time= time.clock()
    #User plays 15 times
    for i in range (16):
        display_word(win,colors)
        full_score_text = "Score: " + str(user_score)
        score_text.setText(full_score_text)
    #End Time
    end_time= time.clock()

    #Display Time Taken
    total_time= round(end_time - start_time)
    time_text=Text(Point(5,3),"Time Taken: " + str(total_time))
    time_text.setFill("magenta")
    time_text.setSize(35)
    time_text.draw(win)

    #ask if they want to try again
    ask= raw_input("Do you want to play again? Enter [Y]es if so: ")
    if ask.lower()=="y" or ask.lower()=="yes":
        user_score=0
        score_text.setText("Score: " + str(user_score))
        time_text.undraw()
        #restart the game if they want
        start_game(win,colors,score_text)
    else:
        print "GAME OVER"

    
    #close window if clicked
    win.getMouse()
    win.close()
    
def main():
    global user_score
    
    #List of colors that will be displayed
    colors=["red","blue","yellow","green","purple","orange"]

    #Create a graph window with a gray background        
    win= GraphWin("STROOP TEST", 500,600)
    win.setCoords(0,0,10,10)
    win.setBackground("gray")

    #Set Up Style for Window
    title=Text(Point(5,8),"STROOP TEST")
    title.setSize(25)
    title.draw(win)
    #Draw a rectangle around word
    rectangle=Rectangle(Point(2,4.5),Point(8,6.5))
    rectangle.setFill("White")
    rectangle.draw(win)
    #Display score text on the window
    score_text=Text(Point(5,2),"Score: ")
    score_text.setSize(25)
    score_text.draw(win)
    start_game(win,colors,score_text)
    win.getMouse()
    win.close()


if __name__=="__main__":
    main()
