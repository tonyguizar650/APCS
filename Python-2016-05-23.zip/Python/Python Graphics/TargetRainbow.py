from graphics import *

"""
Marlene and Tony
This program will draw a target and a rainbow
"""

#Target Function

"""
Draws a target using 3 diffent sized circles that are red or white.
"""
def draw_centered_circle():
    width = 400
    height = 200
    #This is my list of divisors that I will use to make the radius smaller
    nums=[2,3,5.5]
    #This is the list of colors that the circles need to be
    colors=["red","white","red"]
    # create a window and tell it y increases upwards
    win = GraphWin("Target", width, height)
    win.yUp()
    # create a point at the center
    center = Point(width/2, height/2)
    # create a circle centered at the center
    # with a radius of half the height
    
    for num in range(0,len(nums)):
        #This is going to take the number in the nums list to be the divisor
        divisor = nums[num]
        #This is going to take the color in the colors list to be the color of
        #the whole circle and the ouline
        color = colors[num]
        circle = Circle(center, height/divisor)
        #sets color inside circle
        circle.setFill(color)
        # sets the outline
        circle.setOutline(color)
        # add the circle to the window
        circle.draw(win)
        
        

#Rainbow Function
        
#I defined these globally because I could not figure out how to arrange them into arguments
#Create a graphing window 
win= GraphWin("Rainbow",500,500)
win.yUp()
#List with all the colors of the rainbown in it
colors=["red","orange","yellow","green","blue","purple","white"]

'''
This method will make the archs of the rainbow and will have take 2 arguments, a
radius and a color variable
'''
def make_arch(radius,color):

          circle=Circle(Point(250,-30),radius)
          circle.setFill(color)
          circle.draw(win)
          
'''
This method will be my main function and it will call the make_arch method for each arch to create a rainbow
'''
def draw_rainbow():
          #call the make_arch method 7 times for each color of the rainbow with different radii and colors each time
          make_arch(220,colors[0])
          make_arch(200,colors[1])
          make_arch(180,colors[2])
          make_arch(160,colors[3])
          make_arch(140,colors[4])
          make_arch(120,colors[5])
          make_arch(100,colors[6])

"""
This function will let us call the fuctions that we need
"""
def main():
    draw_centered_circle()
    draw_rainbow()

# lets us run the main function only when we are running this file
if __name__ == "__main__":
    main()

#close the window when the user clicks on it
win.getMouse()
win.close()
