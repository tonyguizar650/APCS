'''
Tony and Darian. This program will make  ball bounce as if there were gravity
'''
from graphics import *
import time
import random
'''
This method will draw the circle that will be in motion
'''

'''
This will make the ball bonce up and down
'''
def move_ball(win,circle,distance):
    #bounces down
    for i in range(distance):
        circle.move(0,-i)
        time.sleep(.04)
    #bounces up
    for i in range(distance):
        circle.move(0,i)
        time.sleep(.04)
'''
This method will draw the ball and call the move_ball method
'''
def bounce_ball(win):
    #ball will be a random color every time the program is random
    color=color_rgb(random.randint(0,255),random.randint(0,255),random.randint(0,255))
    #random position every time
    xcor=random.randint(-30,30)
    #Draw a circle that changes color each time
    circle=Circle(Point(xcor,50),30)
    circle.setFill(color)
    circle.draw(win)
    # move the ball up and down
    time.sleep(.5)
    return circle
    
'''
This main function will call all the methods 
'''
def main():
    win=GraphWin("Bounce Ball", 500, 300)
    win.setCoords(-500,-300,500,300)
    for i in range(30):
        circle=bounce_ball(win)
        move_ball(win,circle,27)
    #closes the window upon clicking on it
    win.getMouse()
    win.close()

'''
Only run if it is this program
'''
if __name__=="__main__":
    main()
